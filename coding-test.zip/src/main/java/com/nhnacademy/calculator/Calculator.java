/*
 * +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 * + Copyright 2023. NHN Academy Corp. All rights reserved.
 * + * While every precaution has been taken in the preparation of this resource,  assumes no
 * + responsibility for errors or omissions, or for damages resulting from the use of the information
 * + contained herein
 * + No part of this resource may be reproduced, stored in a retrieval system, or transmitted, in any
 * + form or by any means, electronic, mechanical, photocopying, recording, or otherwise, without the
 * + prior written permission.
 * +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 */

package com.nhnacademy.calculator;

import com.nhnacademy.number.MyNumber;

import java.util.List;

public class Calculator {
    public static List<String> parsing(String expression) {
        return null;
    }
    
    public static List<String> infixToPostfix(List<String> arr) {
        return null;
    }

    public static <T extends MyNumber> T run(String expression) {
        return null;
    }

}
